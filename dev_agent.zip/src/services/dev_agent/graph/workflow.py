"""graph/workflow.py — StateGraph 组装"""
from langgraph.graph import StateGraph, START, END
from shared.agents.agent_state import AgentState
from graph.nodes import (
    entry_node, supervisor_node, researcher_node,
    coder_node, reviewer_node, reflection_node, final_answer_node,
)


def build_graph() -> StateGraph:
    g = StateGraph(AgentState)
    g.add_node("Entry",       entry_node)
    g.add_node("Supervisor",  supervisor_node)
    g.add_node("Researcher",  researcher_node)
    g.add_node("Coder",       coder_node)
    g.add_node("Reviewer",    reviewer_node)
    g.add_node("Reflection",  reflection_node)
    g.add_node("Final_Answer", final_answer_node)

    g.add_edge(START, "Entry")
    g.add_edge("Entry", "Supervisor")

    g.add_conditional_edges(
        "Supervisor",
        lambda s: s.get("next", "Final_Answer"),
        {"Researcher": "Researcher", "Coder": "Coder",
         "Reviewer": "Reviewer", "Final_Answer": "Final_Answer"},
    )

    g.add_edge("Researcher",  "Reflection")
    g.add_edge("Reflection",  "Supervisor")
    g.add_edge("Coder",       "Supervisor")
    g.add_edge("Reviewer",    "Final_Answer")
    g.add_edge("Final_Answer", END)
    return g
